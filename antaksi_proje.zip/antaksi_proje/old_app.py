from flask import Flask, render_template, jsonify, send_from_directory
import os

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/frontend')
def frontend():
    return render_template('Frontend Geliştirmeleri.html')

@app.route('/api')
def api():
    return jsonify({
        "status": "success",
        "message": "Antaksi API Çalışıyor",
        "project": "Antaksi Projesi",
        "files": {
            "templates": ["index.html", "Frontend Geliştirmeleri.html"],
            "static": ["css/style.css", "js/script.js"],
            "python": [
                "antaksi api.py",
                "antaksi Migration Script .py",
                "marti_app_with_ui.py",
                "app.py"
            ]
        }
    })

@app.route('/health')
def health():
    return jsonify({"status": "healthy", "timestamp": "2025-12-27"})

if __name__ == '__main__':
    print("=" * 50)
    print("🚀 Antaksi Projesi Başlatılıyor...")
    print("🌐 http://127.0.0.1:5000")
    print("📁 Templates:", os.listdir('templates'))
    print("📁 Static:", os.listdir('static'))
    print("=" * 50)
    app.run(debug=True, port=5000, host='127.0.0.1')