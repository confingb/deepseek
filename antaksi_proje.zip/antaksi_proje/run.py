from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import random
import string
import os

app = Flask(__name__)

# Config
app.config['SECRET_KEY'] = 'antaksi-pro-super-secret-2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(os.path.dirname(os.path.abspath(__file__)), 'instance', 'antaksi.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)

# ========== MODELS ==========
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), default='passenger')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

login_manager.login_view = 'login'

# ========== ROUTES ==========
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('auth/login.html')

@app.route('/register')
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('auth/register.html')

@app.route('/booking')
@login_required
def booking():
    return render_template('booking.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/estimate', methods=['POST'])
def estimate_fare():
    data = request.json
    
    pickup = data.get('pickup', '')
    destination = data.get('destination', '')
    vehicle_type = data.get('vehicle_type', 'standard')
    
    if not pickup or not destination:
        return jsonify({'error': 'Lokasyon gerekli'}), 400
    
    distance = random.uniform(2, 20)
    duration = random.randint(10, 60)
    
    base_fare = 15.0
    per_km = 8.5
    per_minute = 1.2
    
    distance_fare = distance * per_km
    time_fare = duration * per_minute
    total = base_fare + distance_fare + time_fare
    
    vehicle_multipliers = {'standard': 1.0, 'comfort': 1.3, 'premium': 1.7, 'van': 2.0}
    multiplier = vehicle_multipliers.get(vehicle_type, 1.0)
    total *= multiplier
    
    total = max(total, 30.0)
    
    return jsonify({
        'success': True,
        'estimated': {
            'distance_km': round(distance, 2),
            'duration_min': duration,
            'fare': round(total, 2),
            'vehicle_type': vehicle_type
        }
    })

@app.route('/api/book', methods=['POST'])
@login_required
def book_trip():
    data = request.json
    
    required = ['pickup', 'destination', 'vehicle_type']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} alanı gereklidir'}), 400
    
    trip_code = 'ANT' + ''.join(random.choices(string.digits, k=7))
    
    return jsonify({
        'success': True,
        'message': 'Rezervasyon başarılı!',
        'trip_code': trip_code,
        'estimated_fare': round(random.uniform(30, 150), 2)
    })

@app.route('/api/districts')
def districts():
    districts = ['Muratpaşa', 'Konyaaltı', 'Kepez', 'Döşemealtı', 'Aksu', 'Serik']
    return jsonify({'districts': districts})

@app.route('/api/vehicle-types')
def vehicle_types():
    types = {
        'standard': {'name': 'Standart', 'multiplier': 1.0, 'icon': '🚗'},
        'comfort': {'name': 'Konfor', 'multiplier': 1.3, 'icon': '🚙'},
        'premium': {'name': 'Premium', 'multiplier': 1.7, 'icon': '🚘'}
    }
    return jsonify({'types': types})

# ========== AUTH API ==========
@app.route('/api/login', methods=['POST'])
def api_login():
    data = request.json
    
    identifier = data.get('identifier')
    password = data.get('password')
    
    if not identifier or not password:
        return jsonify({'error': 'E-posta/telefon ve şifre gereklidir'}), 400
    
    # Demo kullanıcı kontrolü
    if identifier == 'demo@antaksi.com' and password == 'demo123':
        user = User.query.filter_by(email='demo@antaksi.com').first()
        if not user:
            # Demo kullanıcı oluştur
            user = User(
                email='demo@antaksi.com',
                phone='05552223344',
                first_name='Demo',
                last_name='User',
                user_type='passenger'
            )
            user.set_password('demo123')
            db.session.add(user)
            db.session.commit()
        
        login_user(user)
        return jsonify({
            'success': True,
            'user': {
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'user_type': user.user_type
            }
        })
    
    return jsonify({'error': 'E-posta/telefon veya şifre hatalı'}), 401

@app.route('/api/register', methods=['POST'])
def api_register():
    data = request.json
    
    required = ['email', 'phone', 'first_name', 'last_name', 'password']
    for field in required:
        if not data.get(field):
            return jsonify({'error': f'{field} alanı gereklidir'}), 400
    
    # Yeni kullanıcı oluştur
    user = User(
        email=data['email'],
        phone=data['phone'].replace(' ', '').replace('-', ''),
        first_name=data['first_name'],
        last_name=data['last_name'],
        user_type=data.get('user_type', 'passenger')
    )
    user.set_password(data['password'])
    
    db.session.add(user)
    db.session.commit()
    
    login_user(user)
    
    return jsonify({
        'success': True,
        'message': 'Kayıt başarılı!',
        'user': {
            'id': user.id,
            'email': user.email,
            'first_name': user.first_name,
            'last_name': user.last_name,
            'user_type': user.user_type
        }
    })

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# ========== BAŞLATMA ==========
if __name__ == '__main__':
    with app.app_context():
        # instance klasörünü oluştur
        os.makedirs('instance', exist_ok=True)
        
        # Veritabanını oluştur
        db.create_all()
        
        # Demo kullanıcı oluştur (eğer yoksa)
        if not User.query.filter_by(email='demo@antaksi.com').first():
            demo = User(
                email='demo@antaksi.com',
                phone='05552223344',
                first_name='Demo',
                last_name='User',
                user_type='passenger'
            )
            demo.set_password('demo123')
            db.session.add(demo)
            db.session.commit()
            print('✅ Demo kullanıcı oluşturuldu')
        
        # Admin kullanıcısı oluştur (eğer yoksa)
        if not User.query.filter_by(email='admin@antaksi.com').first():
            admin = User(
                email='admin@antaksi.com',
                phone='05551112233',
                first_name='Admin',
                last_name='User',
                user_type='admin'
            )
            admin.set_password('admin123')
            db.session.add(admin)
            db.session.commit()
            print('✅ Admin kullanıcısı oluşturuldu')
    
    print("\n" + "="*70)
    print("🚖 ANTAKSİ PROFESYONEL TAKSİ SİSTEMİ")
    print("="*70)
    print("🌐 Ana Sayfa:        http://127.0.0.1:5000")
    print("🔐 Giriş:            http://127.0.0.1:5000/login")
    print("📝 Kayıt:            http://127.0.0.1:5000/register")
    print("📱 Rezervasyon:      http://127.0.0.1:5000/booking")
    print("📊 Dashboard:        http://127.0.0.1:5000/dashboard")
    print("🗺️ İlçeler API:      http://127.0.0.1:5000/api/districts")
    print("💰 Araç Tipleri:     http://127.0.0.1:5000/api/vehicle-types")
    print("="*70 + "\n")
    
    app.run(debug=True, host='127.0.0.1', port=5000)