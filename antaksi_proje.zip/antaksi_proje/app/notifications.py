from flask import Blueprint, jsonify, request
from flask_login import login_required, current_user
from app import db
from app.models import Trip, Notification
from datetime import datetime
import json

notifications_bp = Blueprint('notifications', __name__)

# WebSocket veya Server-Sent Events için basit bir pub/sub sistemi
active_connections = {}

@notifications_bp.route('/api/notifications')
@login_required
def get_notifications():
    notifications = Notification.query.filter_by(
        user_id=current_user.id,
        read=False
    ).order_by(Notification.created_at.desc()).limit(20).all()
    
    notifications_data = []
    for notif in notifications:
        notifications_data.append({
            'id': notif.id,
            'title': notif.title,
            'message': notif.message,
            'type': notif.type,
            'created_at': notif.created_at.strftime('%H:%M'),
            'data': notif.data
        })
    
    return jsonify({'notifications': notifications_data})

@notifications_bp.route('/api/notifications/mark-read', methods=['POST'])
@login_required
def mark_notifications_read():
    Notification.query.filter_by(
        user_id=current_user.id,
        read=False
    ).update({'read': True})
    
    db.session.commit()
    
    return jsonify({'success': True})

def send_trip_notification(trip_id, notification_type, data=None):
    """Yolculuk bildirimi gönder"""
    trip = Trip.query.get(trip_id)
    if not trip:
        return
    
    title_map = {
        'trip_created': 'Yeni Yolculuk Talebi',
        'driver_assigned': 'Sürücü Atandı',
        'driver_arrived': 'Sürücü Geldi',
        'trip_started': 'Yolculuk Başladı',
        'trip_completed': 'Yolculuk Tamamlandı',
        'trip_cancelled': 'Yolculuk İptal Edildi'
    }
    
    message_map = {
        'trip_created': 'Yolculuk talebiniz alındı. Sürücü aranıyor...',
        'driver_assigned': f'{data.get("driver_name")} sürücünüz yolculuğunuzu kabul etti.',
        'driver_arrived': 'Sürücünüz varış noktasına ulaştı.',
        'trip_started': 'Yolculuğunuz başladı. İyi yolculuklar!',
        'trip_completed': 'Yolculuğunuz tamamlandı. Değerlendirmenizi yapabilirsiniz.',
        'trip_cancelled': 'Yolculuğunuz iptal edildi.'
    }
    
    # Yolcuya bildirim
    passenger_notif = Notification(
        user_id=trip.passenger_id,
        title=title_map.get(notification_type, 'Bildirim'),
        message=message_map.get(notification_type, ''),
        type=notification_type,
        data=json.dumps(data) if data else None
    )
    db.session.add(passenger_notif)
    
    # Sürücüye bildirim (eğer atandıysa)
    if trip.driver_id:
        driver_notif = Notification(
            user_id=trip.assigned_driver.user_id,
            title=title_map.get(notification_type, 'Bildirim'),
            message=message_map.get(notification_type, ''),
            type=notification_type,
            data=json.dumps(data) if data else None
        )
        db.session.add(driver_notif)
    
    db.session.commit()
    
    # Real-time güncelleme için (WebSocket/SocketIO)
    # Burada SocketIO.emit() çağrılır