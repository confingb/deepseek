from datetime import datetime
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from app import db, login_manager

class User(UserMixin, db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone = db.Column(db.String(20), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    user_type = db.Column(db.String(20), default='passenger')  # passenger, driver, admin
    is_active = db.Column(db.Boolean, default=True)
    email_verified = db.Column(db.Boolean, default=False)
    phone_verified = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)
    
    # İlişkiler
    trips = db.relationship('Trip', backref='passenger', lazy='dynamic', foreign_keys='Trip.passenger_id')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_full_name(self):
        return f"{self.first_name} {self.last_name}"

class Driver(db.Model):
    __tablename__ = 'drivers'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), unique=True)
    license_number = db.Column(db.String(50), unique=True)
    car_plate = db.Column(db.String(20), unique=True)
    car_model = db.Column(db.String(50))
    car_color = db.Column(db.String(30))
    car_year = db.Column(db.Integer)
    rating = db.Column(db.Float, default=5.0)
    total_trips = db.Column(db.Integer, default=0)
    is_online = db.Column(db.Boolean, default=False)
    is_available = db.Column(db.Boolean, default=True)
    current_location = db.Column(db.String(200))
    current_lat = db.Column(db.Float)
    current_lng = db.Column(db.Float)
    approved = db.Column(db.Boolean, default=False)
    
    user = db.relationship('User', backref='driver_profile', uselist=False)
    trips = db.relationship('Trip', backref='assigned_driver', lazy='dynamic', foreign_keys='Trip.driver_id')

class Trip(db.Model):
    __tablename__ = 'trips'
    
    id = db.Column(db.Integer, primary_key=True)
    trip_code = db.Column(db.String(10), unique=True, nullable=False)
    passenger_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    driver_id = db.Column(db.Integer, db.ForeignKey('drivers.id'))
    
    # Konum bilgileri
    pickup_address = db.Column(db.String(200), nullable=False)
    pickup_district = db.Column(db.String(50))
    pickup_neighborhood = db.Column(db.String(50))
    pickup_street = db.Column(db.String(100))
    pickup_lat = db.Column(db.Float)
    pickup_lng = db.Column(db.Float)
    
    destination_address = db.Column(db.String(200), nullable=False)
    destination_district = db.Column(db.String(50))
    destination_neighborhood = db.Column(db.String(50))
    destination_street = db.Column(db.String(100))
    destination_lat = db.Column(db.Float)
    destination_lng = db.Column(db.Float)
    
    # Yolculuk detayları
    distance_km = db.Column(db.Float)
    estimated_duration = db.Column(db.Integer)  # dakika
    estimated_fare = db.Column(db.Float)
    actual_fare = db.Column(db.Float)
    vehicle_type = db.Column(db.String(20), default='standard')
    
    # Durumlar
    status = db.Column(db.String(30), default='pending')  # pending, searching, accepted, arrived, ongoing, completed, cancelled
    payment_status = db.Column(db.String(20), default='pending')
    payment_method = db.Column(db.String(30))
    
    # Zaman damgaları
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime)
    arrived_at = db.Column(db.DateTime)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # Değerlendirme
    driver_rating = db.Column(db.Float)
    passenger_rating = db.Column(db.Float)
    notes = db.Column(db.Text)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))