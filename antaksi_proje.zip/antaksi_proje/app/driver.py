from flask import Blueprint, render_template, jsonify, request, session
from flask_login import login_required, current_user
from app import db
from app.models import Driver, Trip, User
from datetime import datetime
import json

driver_bp = Blueprint('driver', __name__, url_prefix='/driver')

@driver_bp.route('/dashboard')
@login_required
def dashboard():
    if current_user.user_type != 'driver':
        return redirect(url_for('main.index'))
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return redirect(url_for('main.index'))
    
    # Aktif yolculuklar
    active_trips = Trip.query.filter_by(
        driver_id=driver.id,
        status__in=['accepted', 'arrived', 'ongoing']
    ).order_by(Trip.created_at.desc()).all()
    
    # Bugünkü yolculuklar
    today = datetime.utcnow().date()
    today_trips = Trip.query.filter(
        Trip.driver_id == driver.id,
        db.func.date(Trip.created_at) == today
    ).all()
    
    # İstatistikler
    total_trips = Trip.query.filter_by(driver_id=driver.id).count()
    completed_trips = Trip.query.filter_by(driver_id=driver.id, status='completed').count()
    total_earnings = db.session.query(db.func.sum(Trip.actual_fare)).filter(
        Trip.driver_id == driver.id,
        Trip.status == 'completed',
        Trip.payment_status == 'completed'
    ).scalar() or 0
    
    return render_template('driver/dashboard.html',
                         driver=driver,
                         active_trips=active_trips,
                         today_trips=today_trips,
                         total_trips=total_trips,
                         completed_trips=completed_trips,
                         total_earnings=total_earnings)

@driver_bp.route('/trips')
@login_required
def trips():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    trips = Trip.query.filter_by(driver_id=driver.id).order_by(Trip.created_at.desc()).limit(50).all()
    
    trips_data = []
    for trip in trips:
        trips_data.append({
            'id': trip.id,
            'code': trip.trip_code,
            'passenger': trip.passenger.get_full_name() if trip.passenger else 'Bilinmiyor',
            'pickup': trip.pickup_address,
            'destination': trip.destination_address,
            'fare': trip.actual_fare or trip.estimated_fare,
            'status': trip.status,
            'created_at': trip.created_at.strftime('%d.%m.%Y %H:%M'),
            'vehicle_type': trip.vehicle_type
        })
    
    return jsonify({'trips': trips_data})

@driver_bp.route('/set-online', methods=['POST'])
@login_required
def set_online():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    data = request.json
    is_online = data.get('is_online', False)
    
    driver.is_online = is_online
    driver.is_available = is_online  # Online ise available
    
    db.session.commit()
    
    return jsonify({
        'success': True,
        'is_online': driver.is_online,
        'is_available': driver.is_available
    })

@driver_bp.route('/update-location', methods=['POST'])
@login_required
def update_location():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    data = request.json
    lat = data.get('lat')
    lng = data.get('lng')
    address = data.get('address')
    
    if lat and lng:
        driver.current_lat = lat
        driver.current_lng = lng
        driver.current_location = address
    
    db.session.commit()
    
    return jsonify({'success': True})

@driver_bp.route('/trip/<int:trip_id>/accept', methods=['POST'])
@login_required
def accept_trip(trip_id):
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    trip = Trip.query.get(trip_id)
    if not trip:
        return jsonify({'error': 'Yolculuk bulunamadı'}), 404
    
    if trip.status != 'searching':
        return jsonify({'error': 'Bu yolculuk artık müsait değil'}), 400
    
    # Sürücüyü yolculuğa ata
    trip.driver_id = driver.id
    trip.status = 'accepted'
    trip.accepted_at = datetime.utcnow()
    
    # Sürücüyü müsait değil yap
    driver.is_available = False
    
    db.session.commit()
    
    # Burada bildirim gönderilir (WebSocket veya push notification)
    
    return jsonify({
        'success': True,
        'trip': {
            'id': trip.id,
            'code': trip.trip_code,
            'passenger': trip.passenger.get_full_name(),
            'pickup': trip.pickup_address,
            'destination': trip.destination_address,
            'fare': trip.estimated_fare
        }
    })

@driver_bp.route('/trip/<int:trip_id>/status', methods=['POST'])
@login_required
def update_trip_status(trip_id):
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    trip = Trip.query.get(trip_id)
    if not trip:
        return jsonify({'error': 'Yolculuk bulunamadı'}), 404
    
    if trip.driver_id != driver.id:
        return jsonify({'error': 'Bu yolculuk size ait değil'}), 403
    
    data = request.json
    status = data.get('status')
    
    valid_statuses = ['arrived', 'ongoing', 'completed', 'cancelled']
    if status not in valid_statuses:
        return jsonify({'error': 'Geçersiz durum'}), 400
    
    trip.status = status
    
    # Duruma göre zaman damgası ekle
    now = datetime.utcnow()
    if status == 'arrived':
        trip.arrived_at = now
    elif status == 'ongoing':
        trip.started_at = now
    elif status == 'completed':
        trip.completed_at = now
        driver.is_available = True  # Sürücü tekrar müsait olur
        driver.total_trips += 1
    
    db.session.commit()
    
    return jsonify({'success': True, 'status': status})

@driver_bp.route('/earnings')
@login_required
def earnings():
    if current_user.user_type != 'driver':
        return jsonify({'error': 'Yetkisiz erişim'}), 403
    
    driver = Driver.query.filter_by(user_id=current_user.id).first()
    if not driver:
        return jsonify({'error': 'Sürücü bulunamadı'}), 404
    
    # Haftalık kazançlar
    import datetime
    today = datetime.date.today()
    week_ago = today - datetime.timedelta(days=7)
    
    weekly_earnings = db.session.query(
        db.func.date(Trip.completed_at),
        db.func.sum(Trip.actual_fare)
    ).filter(
        Trip.driver_id == driver.id,
        Trip.status == 'completed',
        Trip.payment_status == 'completed',
        Trip.completed_at >= week_ago
    ).group_by(db.func.date(Trip.completed_at)).all()
    
    earnings_data = []
    for date, amount in weekly_earnings:
        earnings_data.append({
            'date': date.strftime('%d.%m'),
            'amount': float(amount) if amount else 0
        })
    
    return jsonify({'earnings': earnings_data})