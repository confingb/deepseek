from flask import Blueprint, jsonify, request
import random

location = Blueprint('location', __name__)

# Antalya ilçeleri ve mahalleleri
ANTALYA_DISTRICTS = {
    'Muratpaşa': ['Bahçelievler', 'Çağlayan', 'Fener', 'Konyaaltı', 'Lara', 'Meltem', 'Şirinyalı', 'Yeşilbahçe'],
    'Konyaaltı': ['Arapsuyu', 'Limak', 'Liman', 'Altınkum', 'Gürsu', 'Çakırlar', 'Güzelyurt'],
    'Kepez': ['Çallı', 'Erenköy', 'Eskiköy', 'Hacıhaliller', 'Kirişçiler', 'Sütçüler', 'Yeni Doğan'],
    'Döşemealtı': ['Akkayalar', 'Çığlık', 'Dağbeli', 'Kovanlık', 'Yeşilbayır'],
    'Aksu': ['Aksu', 'Alaylı', 'Altıntaş', 'Çalkaya', 'Kırıntı', 'Yurtpınar'],
    'Serik': ['Abdurrahmanlar', 'Belek', 'Boğazkent', 'Çandır', 'Gebiz', 'Kadriye', 'Köprübaşı']
}

# Antalya caddeleri (örnek)
ANTALYA_STREETS = [
    'Atatürk Bulvarı', 'Dumlupınar Bulvarı', 'Fevzi Çakmak Caddesi', 'Konyaaltı Caddesi',
    'Lara Caddesi', 'Meltem Caddesi', 'Şirinyalı Caddesi', 'Yeşilbahçe Caddesi',
    'Çallı Caddesi', 'Erenköy Caddesi', 'Bahçelievler Caddesi', 'Çağlayan Caddesi'
]

class LocationService:
    @staticmethod
    def get_districts():
        """Antalya ilçelerini getir"""
        return list(ANTALYA_DISTRICTS.keys())
    
    @staticmethod
    def get_neighborhoods(district):
        """İlçenin mahallelerini getir"""
        return ANTALYA_DISTRICTS.get(district, [])
    
    @staticmethod
    def get_streets():
        """Cadde listesini getir"""
        return ANTALYA_STREETS
    
    @staticmethod
    def geocode_address(address):
        """Adresi koordinatlara çevir (simülasyon)"""
        # Gerçek uygulamada Google Maps API kullanılır
        return {
            'lat': 36.8841 + random.uniform(-0.05, 0.05),  # Antalya merkez
            'lng': 30.7056 + random.uniform(-0.05, 0.05)
        }
    
    @staticmethod
    def calculate_distance(lat1, lng1, lat2, lng2):
        """İki koordinat arası mesafe hesapla (simülasyon)"""
        # Basit mesafe hesaplama (gerçekte Haversine formülü)
        import math
        R = 6371  # Dünya yarıçapı km
        
        lat1_rad = math.radians(lat1)
        lat2_rad = math.radians(lat2)
        delta_lat = math.radians(lat2 - lat1)
        delta_lng = math.radians(lng2 - lng1)
        
        a = math.sin(delta_lat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(delta_lng/2)**2
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        
        distance_km = R * c
        return round(distance_km, 2)
    
    @staticmethod
    def estimate_duration(distance_km, traffic_level='normal'):
        """Tahmini süre hesapla"""
        base_minutes = distance_km * 3  # km başına ortalama 3 dakika
        
        # Trafik etkisi
        traffic_multipliers = {
            'low': 0.8,
            'normal': 1.0,
            'high': 1.5,
            'very_high': 2.0
        }
        
        multiplier = traffic_multipliers.get(traffic_level, 1.0)
        estimated_minutes = base_minutes * multiplier
        
        return max(5, int(estimated_minutes))  # Minimum 5 dakika

@location.route('/api/location/districts')
def get_districts():
    return jsonify({'districts': LocationService.get_districts()})

@location.route('/api/location/neighborhoods')
def get_neighborhoods():
    district = request.args.get('district')
    if not district:
        return jsonify({'error': 'İlçe belirtilmedi'}), 400
    
    neighborhoods = LocationService.get_neighborhoods(district)
    return jsonify({'neighborhoods': neighborhoods})

@location.route('/api/location/streets')
def get_streets():
    return jsonify({'streets': LocationService.get_streets()})

@location.route('/api/location/geocode', methods=['POST'])
def geocode():
    data = request.json
    address = data.get('address')
    
    if not address:
        return jsonify({'error': 'Adres belirtilmedi'}), 400
    
    coordinates = LocationService.geocode_address(address)
    return jsonify(coordinates)

@location.route('/api/location/calculate-route', methods=['POST'])
def calculate_route():
    data = request.json
    
    pickup_lat = data.get('pickup_lat')
    pickup_lng = data.get('pickup_lng')
    dest_lat = data.get('dest_lat')
    dest_lng = data.get('dest_lng')
    
    if None in [pickup_lat, pickup_lng, dest_lat, dest_lng]:
        return jsonify({'error': 'Koordinatlar eksik'}), 400
    
    distance = LocationService.calculate_distance(pickup_lat, pickup_lng, dest_lat, dest_lng)
    duration = LocationService.estimate_duration(distance)
    
    return jsonify({
        'distance_km': distance,
        'duration_min': duration,
        'polyline': None  # Gerçek uygulamada Google Maps Directions API'den gelir
    })