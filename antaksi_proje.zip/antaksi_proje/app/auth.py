from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from app import db
from app.models import User, Driver
from werkzeug.security import generate_password_hash, check_password_hash
import re
import random
import string

auth = Blueprint('auth', __name__)

# E-posta regex
EMAIL_REGEX = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
# Telefon regex (Türkiye)
PHONE_REGEX = r'^05[0-9]{9}$'

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identifier = request.form.get('identifier')  # E-posta veya telefon
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False
        
        # E-posta mi telefon mu kontrol et
        if '@' in identifier:
            user = User.query.filter_by(email=identifier).first()
        else:
            # Telefon numarasını temizle
            phone = re.sub(r'\D', '', identifier)
            if len(phone) == 10 and phone.startswith('5'):
                phone = '0' + phone
            user = User.query.filter_by(phone=phone).first()
        
        if not user or not user.check_password(password):
            flash('E-posta/telefon veya şifre hatalı', 'error')
            return redirect(url_for('auth.login'))
        
        if not user.is_active:
            flash('Hesabınız askıya alınmış', 'error')
            return redirect(url_for('auth.login'))
        
        login_user(user, remember=remember)
        user.last_login = datetime.utcnow()
        db.session.commit()
        
        # Kullanıcı tipine göre yönlendirme
        if user.user_type == 'admin':
            return redirect(url_for('admin.dashboard'))
        elif user.user_type == 'driver':
            return redirect(url_for('driver.dashboard'))
        else:
            return redirect(url_for('main.index'))
    
    return render_template('auth/login.html')

@auth.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form.get('email')
        phone = request.form.get('phone')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        user_type = request.form.get('user_type', 'passenger')
        
        # Validasyon
        errors = []
        
        # E-posta kontrolü
        if not re.match(EMAIL_REGEX, email):
            errors.append('Geçerli bir e-posta adresi girin')
        
        # Telefon kontrolü
        phone_clean = re.sub(r'\D', '', phone)
        if not re.match(PHONE_REGEX, phone_clean):
            errors.append('Geçerli bir telefon numarası girin (05XXXXXXXXX)')
        
        # Şifre kontrolü
        if len(password) < 6:
            errors.append('Şifre en az 6 karakter olmalı')
        if password != confirm_password:
            errors.append('Şifreler eşleşmiyor')
        
        # Benzersizlik kontrolü
        if User.query.filter_by(email=email).first():
            errors.append('Bu e-posta adresi zaten kullanılıyor')
        if User.query.filter_by(phone=phone_clean).first():
            errors.append('Bu telefon numarası zaten kullanılıyor')
        
        if errors:
            for error in errors:
                flash(error, 'error')
            return redirect(url_for('auth.register'))
        
        # Yeni kullanıcı oluştur
        user = User(
            email=email,
            phone=phone_clean,
            first_name=first_name,
            last_name=last_name,
            user_type=user_type
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Eğer sürücü ise driver kaydı oluştur
        if user_type == 'driver':
            driver = Driver(
                user_id=user.id,
                license_number=request.form.get('license_number'),
                car_plate=request.form.get('car_plate'),
                car_model=request.form.get('car_model'),
                car_color=request.form.get('car_color'),
                car_year=request.form.get('car_year'),
                approved=False  # Admin onayı bekleyecek
            )
            db.session.add(driver)
            db.session.commit()
        
        flash('Kayıt başarılı! Lütfen giriş yapın.', 'success')
        return redirect(url_for('auth.login'))
    
    return render_template('auth/register.html')

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Başarıyla çıkış yaptınız', 'success')
    return redirect(url_for('main.index'))

@auth.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Şifre sıfırlama tokenı oluştur (gerçek uygulamada e-posta gönderilir)
            token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
            # Burada token veritabanına kaydedilir ve e-posta gönderilir
            flash('Şifre sıfırlama bağlantısı e-posta adresinize gönderildi', 'info')
        else:
            flash('Bu e-posta adresi kayıtlı değil', 'error')
        
        return redirect(url_for('auth.forgot_password'))
    
    return render_template('auth/reset_password.html')

# API endpoints
@auth.route('/api/check-email')
def check_email():
    email = request.args.get('email')
    exists = User.query.filter_by(email=email).first() is not None
    return jsonify({'exists': exists})

@auth.route('/api/check-phone')
def check_phone():
    phone = request.args.get('phone')
    phone_clean = re.sub(r'\D', '', phone)
    exists = User.query.filter_by(phone=phone_clean).first() is not None
    return jsonify({'exists': exists})