"""
ANTARTAXI - Gelişmiş Taksi/Ulaşım Platformu API
Versiyon: 2.0
Geliştirici: DeepSeek AI Asistanı
"""

from __future__ import annotations

import base64
import datetime
import hashlib
import hmac
import json
import os
import sqlite3
import time
import uuid
import math
from pathlib import Path
from typing import Optional, List, Dict, Any
from enum import Enum
from dataclasses import dataclass

from fastapi import FastAPI, HTTPException, Depends, Header, status, WebSocket, WebSocketDisconnect, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, EmailStr, validator
from datetime import timedelta

# =============================================
# KONFİGÜRASYON
# =============================================

DB_PATH = Path(__file__).with_suffix(".secure.db")
SECRET_KEY = os.environ.get("ANTAKSI_SECRET", "antaksi_super_secret_key_2.0")
DEFAULT_COMMISSION = 0.1
API_RATE_LIMIT = 100  # Dakikada maksimum istek

# CORS ayarları
CORS_ORIGINS = [
    "http://localhost:8000",
    "http://localhost:3000",
    "http://127.0.0.1:8000",
    "https://antaksi.com",
    "https://www.antaksi.com",
]

# =============================================
# ENUM'lar
# =============================================

class UserRole(str, Enum):
    USER = "user"
    DRIVER = "driver"
    ADMIN = "admin"
    DISPATCHER = "dispatcher"

class RideStatus(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"

class PaymentStatus(str, Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    REFUNDED = "refunded"

class PaymentMethod(str, Enum):
    CASH = "cash"
    CREDIT_CARD = "credit_card"
    WALLET = "wallet"
    MOBILE = "mobile"

class VehicleType(str, Enum):
    STANDARD = "standard"
    COMFORT = "comfort"
    PREMIUM = "premium"
    VAN = "van"
    MOTORCYCLE = "motorcycle"

# =============================================
# VERİTABANI BAĞLANTISI
# =============================================

def init_db():
    """Gelişmiş veritabanı tablolarını oluşturur."""
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    
    # Users tablosu - genişletilmiş
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            email TEXT UNIQUE,
            phone TEXT UNIQUE,
            name TEXT NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL,
            is_active INTEGER NOT NULL DEFAULT 1,
            is_banned INTEGER NOT NULL DEFAULT 0,
            ban_reason TEXT,
            wallet_balance REAL NOT NULL DEFAULT 0.0,
            rating REAL DEFAULT 5.0,
            total_rides INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            last_login TEXT,
            profile_pic TEXT
        )
    """)
    
    # User profiles
    c.execute("""
        CREATE TABLE IF NOT EXISTS user_profiles (
            user_id TEXT PRIMARY KEY,
            date_of_birth TEXT,
            gender TEXT,
            preferences TEXT,  -- JSON formatında tercihler
            emergency_contact TEXT,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Customers (yolcular)
    c.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            user_id TEXT PRIMARY KEY,
            favorite_driver_id TEXT,
            default_payment_method TEXT,
            total_spent REAL DEFAULT 0.0,
            FOREIGN KEY(user_id) REFERENCES users(id),
            FOREIGN KEY(favorite_driver_id) REFERENCES users(id)
        )
    """)
    
    # Drivers - genişletilmiş
    c.execute("""
        CREATE TABLE IF NOT EXISTS drivers (
            user_id TEXT PRIMARY KEY,
            license_number TEXT UNIQUE,
            vehicle_type TEXT NOT NULL,
            vehicle_model TEXT,
            vehicle_color TEXT,
            plate_number TEXT UNIQUE,
            capacity INTEGER DEFAULT 4,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            available INTEGER NOT NULL DEFAULT 1,
            price_per_km REAL NOT NULL DEFAULT 30.0,
            base_fare REAL DEFAULT 10.0,
            min_fare REAL DEFAULT 20.0,
            region_center_lat REAL,
            region_center_lon REAL,
            region_radius_km REAL,
            rating REAL DEFAULT 5.0,
            total_rides INTEGER DEFAULT 0,
            earnings_total REAL DEFAULT 0.0,
            last_ride_end TEXT,
            documents_verified INTEGER DEFAULT 0,
            online INTEGER DEFAULT 1,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Driver documents
    c.execute("""
        CREATE TABLE IF NOT EXISTS driver_documents (
            id TEXT PRIMARY KEY,
            driver_id TEXT NOT NULL,
            document_type TEXT NOT NULL,  -- license, insurance, registration
            document_url TEXT NOT NULL,
            verified INTEGER DEFAULT 0,
            verified_by TEXT,
            verified_at TEXT,
            expiry_date TEXT,
            FOREIGN KEY(driver_id) REFERENCES drivers(user_id)
        )
    """)
    
    # Rides - genişletilmiş
    c.execute("""
        CREATE TABLE IF NOT EXISTS rides (
            id TEXT PRIMARY KEY,
            customer_id TEXT NOT NULL,
            driver_id TEXT NOT NULL,
            vehicle_type TEXT NOT NULL DEFAULT 'standard',
            start_address TEXT NOT NULL,
            end_address TEXT NOT NULL,
            start_lat REAL NOT NULL,
            start_lon REAL NOT NULL,
            end_lat REAL NOT NULL,
            end_lon REAL NOT NULL,
            distance_km REAL NOT NULL,
            duration_minutes REAL,
            price_per_km REAL NOT NULL,
            base_fare REAL NOT NULL,
            total_price REAL NOT NULL,
            commission_rate REAL NOT NULL,
            commission_amount REAL NOT NULL,
            final_price REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            payment_method TEXT,
            payment_status TEXT DEFAULT 'pending',
            scheduled_time TEXT,
            actual_start_time TEXT,
            actual_end_time TEXT,
            created_at TEXT NOT NULL,
            cancelled_by TEXT,
            cancellation_reason TEXT,
            route_polyline TEXT,
            FOREIGN KEY(customer_id) REFERENCES customers(user_id),
            FOREIGN KEY(driver_id) REFERENCES drivers(user_id)
        )
    """)
    
    # Ride waypoints
    c.execute("""
        CREATE TABLE IF NOT EXISTS ride_waypoints (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            sequence INTEGER NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            address TEXT,
            FOREIGN KEY(ride_id) REFERENCES rides(id)
        )
    """)
    
    # Payments
    c.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            customer_id TEXT NOT NULL,
            driver_id TEXT NOT NULL,
            amount REAL NOT NULL,
            commission_amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            transaction_id TEXT UNIQUE,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            completed_at TEXT,
            refund_amount REAL DEFAULT 0.0,
            notes TEXT,
            FOREIGN KEY(ride_id) REFERENCES rides(id),
            FOREIGN KEY(customer_id) REFERENCES customers(user_id),
            FOREIGN KEY(driver_id) REFERENCES drivers(user_id)
        )
    """)
    
    # Ratings
    c.execute("""
        CREATE TABLE IF NOT EXISTS ratings (
            id TEXT PRIMARY KEY,
            ride_id TEXT NOT NULL,
            from_user_id TEXT NOT NULL,
            to_user_id TEXT NOT NULL,
            rating INTEGER NOT NULL CHECK(rating >= 1 AND rating <= 5),
            comment TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(ride_id) REFERENCES rides(id),
            FOREIGN KEY(from_user_id) REFERENCES users(id),
            FOREIGN KEY(to_user_id) REFERENCES users(id)
        )
    """)
    
    # Promotions
    c.execute("""
        CREATE TABLE IF NOT EXISTS promotions (
            id TEXT PRIMARY KEY,
            code TEXT UNIQUE NOT NULL,
            description TEXT,
            discount_type TEXT NOT NULL,  -- percentage, fixed
            discount_value REAL NOT NULL,
            min_order_amount REAL DEFAULT 0.0,
            max_discount REAL,
            valid_from TEXT NOT NULL,
            valid_until TEXT NOT NULL,
            usage_limit INTEGER,
            times_used INTEGER DEFAULT 0,
            is_active INTEGER DEFAULT 1,
            created_by TEXT,
            created_at TEXT NOT NULL
        )
    """)
    
    # User addresses
    c.execute("""
        CREATE TABLE IF NOT EXISTS user_addresses (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,  -- Ev, İş, Okul
            address TEXT NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            is_default INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Driver applications
    c.execute("""
        CREATE TABLE IF NOT EXISTS driver_applications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            vehicle_type TEXT NOT NULL,
            vehicle_model TEXT,
            vehicle_year INTEGER,
            license_number TEXT,
            experience_years INTEGER,
            price_per_km REAL NOT NULL,
            lat REAL NOT NULL,
            lon REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',  -- pending, approved, rejected
            notes TEXT,
            reviewed_by TEXT,
            reviewed_at TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Notifications
    c.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            notification_type TEXT NOT NULL,  -- ride, payment, system, promotion
            is_read INTEGER DEFAULT 0,
            related_id TEXT,  -- ride_id, payment_id vb.
            created_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id)
        )
    """)
    
    # Settings
    c.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT,
            updated_at TEXT NOT NULL,
            updated_by TEXT
        )
    """)
    
    # API logs (rate limiting için)
    c.execute("""
        CREATE TABLE IF NOT EXISTS api_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            endpoint TEXT NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            timestamp TEXT NOT NULL,
            response_time_ms INTEGER
        )
    """)
    
    conn.commit()
    conn.close()

def get_db_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

# =============================================
# GÜVENLİK FONKSİYONLARI
# =============================================

def validate_password(password: str) -> tuple[bool, str]:
    """Parola güvenlik kontrolleri."""
    if len(password) < 8:
        return False, "Parola en az 8 karakter olmalı"
    
    checks = {
        "upper": any(c.isupper() for c in password),
        "lower": any(c.islower() for c in password),
        "digit": any(c.isdigit() for c in password),
        "special": any(not c.isalnum() for c in password)
    }
    
    if not all(checks.values()):
        missing = [k for k, v in checks.items() if not v]
        return False, f"Eksik: {', '.join(missing)}"
    
    return True, "Parola güvenli"

def hash_password(password: str) -> str:
    """PBKDF2 ile güvenli parola hash'leme."""
    salt = hashlib.sha256(SECRET_KEY.encode()).hexdigest()[:16]
    pwdhash = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        salt.encode('utf-8'),
        100000,
        dklen=32
    )
    return salt + pwdhash.hex()

def verify_password(stored_hash: str, provided_password: str) -> bool:
    """Parola doğrulama."""
    if len(stored_hash) < 32:
        return False
    
    salt = stored_hash[:32]
    stored_pwdhash = stored_hash[32:]
    
    pwdhash = hashlib.pbkdf2_hmac(
        'sha256',
        provided_password.encode('utf-8'),
        salt.encode('utf-8'),
        100000,
        dklen=32
    )
    return pwdhash.hex() == stored_pwdhash

def create_token(payload: Dict[str, Any], expires_in: int = 86400) -> str:
    """JWT token oluşturma."""
    header = {"alg": "HS256", "typ": "JWT"}
    payload = payload.copy()
    payload['exp'] = int(time.time()) + expires_in
    payload['iat'] = int(time.time())
    
    def b64(obj):
        data = json.dumps(obj, separators=(',', ':'), ensure_ascii=False).encode('utf-8')
        return base64.urlsafe_b64encode(data).rstrip(b'=').decode('ascii')
    
    signing_input = f"{b64(header)}.{b64(payload)}"
    signature = hmac.new(
        SECRET_KEY.encode('utf-8'),
        signing_input.encode('utf-8'),
        hashlib.sha256
    ).digest()
    
    sig_b64 = base64.urlsafe_b64encode(signature).rstrip(b'=').decode('ascii')
    return f"{signing_input}.{sig_b64}"

def decode_token(token: str) -> Dict[str, Any]:
    """Token doğrulama ve decode."""
    try:
        parts = token.split('.')
        if len(parts) != 3:
            raise ValueError("Geçersiz token formatı")
        
        header_b64, payload_b64, signature_b64 = parts
        
        # İmza doğrulama
        signing_input = f"{header_b64}.{payload_b64}"
        expected_sig = hmac.new(
            SECRET_KEY.encode('utf-8'),
            signing_input.encode('utf-8'),
            hashlib.sha256
        ).digest()
        
        sig = base64.urlsafe_b64decode(signature_b64 + '=' * (-len(signature_b64) % 4))
        
        if not hmac.compare_digest(sig, expected_sig):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Geçersiz token imzası"
            )
        
        # Payload decode
        payload_json = base64.urlsafe_b64decode(payload_b64 + '=' * (-len(payload_b64) % 4))
        payload = json.loads(payload_json.decode('utf-8'))
        
        # Expiry kontrol
        if payload.get('exp', 0) < int(time.time()):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token süresi dolmuş"
            )
        
        return payload
        
    except (ValueError, json.JSONDecodeError, base64.binascii.Error) as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=f"Token çözümlenemedi: {str(e)}"
        )

# =============================================
# DEPENDENCY INJECTION'lar
# =============================================

security = HTTPBearer()

def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security)
) -> Dict[str, Any]:
    """Mevcut kullanıcıyı getir."""
    token = credentials.credentials
    payload = decode_token(token)
    
    conn = get_db_connection()
    c = conn.cursor()
    
    row = c.execute(
        "SELECT id, name, email, phone, role, is_active, is_banned, wallet_balance, rating FROM users WHERE id = ?",
        (payload['sub'],)
    ).fetchone()
    
    conn.close()
    
    if not row:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kullanıcı bulunamadı"
        )
    
    if row['is_banned']:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Hesabınız askıya alınmış"
        )
    
    return {
        "id": row["id"],
        "name": row["name"],
        "email": row["email"],
        "phone": row["phone"],
        "role": row["role"],
        "is_active": bool(row["is_active"]),
        "is_banned": bool(row["is_banned"]),
        "wallet_balance": row["wallet_balance"],
        "rating": row["rating"]
    }

def require_role(*roles: str):
    """Rol bazlı yetkilendirme."""
    def role_checker(user: Dict[str, Any] = Depends(get_current_user)):
        if user['role'] not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu işlem için yetkiniz yok"
            )
        
        # Sürücü kontrolleri
        if user['role'] == 'driver':
            conn = get_db_connection()
            c = conn.cursor()
            driver = c.execute(
                "SELECT documents_verified FROM drivers WHERE user_id = ?",
                (user['id'],)
            ).fetchone()
            conn.close()
            
            if not driver or not driver['documents_verified']:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Sürücü belgeleriniz doğrulanmamış"
                )
        
        return user
    return role_checker

# =============================================
# PYDANTIC MODELLERİ
# =============================================

class RegisterRequest(BaseModel):
    email: Optional[EmailStr] = None
    phone: Optional[str] = None
    name: str
    password: str
    role: UserRole = UserRole.USER
    
    @validator('phone')
    def validate_phone(cls, v):
        if v and not v.startswith('+'):
            raise ValueError("Telefon numarası + ile başlamalı")
        return v
    
    @validator('role')
    def validate_role(cls, v):
        if v not in [UserRole.USER, UserRole.DRIVER]:
            raise ValueError("Geçersiz rol")
        return v

class DriverApplicationRequest(BaseModel):
    name: str
    email: EmailStr
    phone: str
    vehicle_type: VehicleType
    vehicle_model: Optional[str] = None
    vehicle_year: Optional[int] = None
    license_number: str
    experience_years: int = Field(ge=0, le=50)
    price_per_km: float = Field(gt=0, le=100)
    lat: float = Field(ge=-90, le=90)
    lon: float = Field(ge=-180, le=180)
    notes: Optional[str] = None

class LoginRequest(BaseModel):
    identifier: str  # email, phone veya id
    password: str
    role: UserRole

class Location(BaseModel):
    lat: float
    lon: float

class RideRequest(BaseModel):
    start_location: Location
    end_location: Location
    vehicle_type: VehicleType = VehicleType.STANDARD
    scheduled_time: Optional[datetime.datetime] = None
    payment_method: PaymentMethod = PaymentMethod.CASH
    use_wallet: bool = False
    promotion_code: Optional[str] = None

class PaymentRequest(BaseModel):
    ride_id: str
    payment_method: PaymentMethod
    card_token: Optional[str] = None  # Stripe vb. için

class RatingRequest(BaseModel):
    ride_id: str
    rating: int = Field(ge=1, le=5)
    comment: Optional[str] = None

class AddressRequest(BaseModel):
    title: str
    address: str
    lat: float
    lon: float
    is_default: bool = False

# =============================================
# COĞRAFİ HESAPLAMALAR
# =============================================

def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """İki nokta arası mesafe (km)."""
    R = 6371.0
    
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    
    a = math.sin(delta_phi / 2) ** 2 + \
        math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    return R * c

def calculate_ride_price(
    distance_km: float,
    duration_minutes: float,
    price_per_km: float,
    base_fare: float,
    min_fare: float,
    surge_multiplier: float = 1.0
) -> Dict[str, float]:
    """Yolculuk ücretini hesapla."""
    distance_fare = distance_km * price_per_km
    time_fare = duration_minutes * 0.5  # Dakika başına ücret
    
    subtotal = (base_fare + distance_fare + time_fare) * surge_multiplier
    total = max(subtotal, min_fare)
    
    return {
        "base_fare": base_fare,
        "distance_fare": distance_fare,
        "time_fare": time_fare,
        "subtotal": subtotal,
        "total": total,
        "surge_multiplier": surge_multiplier
    }

# =============================================
# WEBSOCKET BAĞLANTI YÖNETİCİSİ
# =============================================

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.driver_locations: Dict[str, Dict] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str):
        await websocket.accept()
        self.active_connections[user_id] = websocket
    
    def disconnect(self, user_id: str):
        if user_id in self.active_connections:
            del self.active_connections[user_id]
        if user_id in self.driver_locations:
            del self.driver_locations[user_id]
    
    async def send_personal_message(self, message: str, user_id: str):
        if user_id in self.active_connections:
            await self.active_connections[user_id].send_text(message)
    
    async def broadcast(self, message: str):
        for connection in self.active_connections.values():
            await connection.send_text(message)
    
    def update_driver_location(self, driver_id: str, lat: float, lon: float):
        self.driver_locations[driver_id] = {
            "lat": lat,
            "lon": lon,
            "updated_at": datetime.datetime.utcnow().isoformat()
        }
    
    def get_nearby_drivers(self, lat: float, lon: float, radius_km: float = 5.0):
        """Belirli yarıçap içindeki sürücüleri bul."""
        nearby = []
        for driver_id, location in self.driver_locations.items():
            distance = haversine_distance(lat, lon, location["lat"], location["lon"])
            if distance <= radius_km:
                nearby.append({
                    "driver_id": driver_id,
                    "distance_km": distance,
                    **location
                })
        return sorted(nearby, key=lambda x: x["distance_km"])

manager = ConnectionManager()

# =============================================
# FASTAPI UYGULAMASI
# =============================================

app = FastAPI(
    title="Antaksi API v2.0",
    description="Gelişmiş Taksi/Ulaşım Platformu",
    version="2.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =============================================
# EVENT HANDLERS
# =============================================

@app.on_event("startup")
async def startup_event():
    """Uygulama başlangıç ayarları."""
    init_db()
    create_default_data()

def create_default_data():
    """Varsayılan verileri oluştur."""
    conn = get_db_connection()
    c = conn.cursor()
    
    # Varsayılan admin
    admin_exists = c.execute(
        "SELECT id FROM users WHERE role = 'admin'"
    ).fetchone()
    
    if not admin_exists:
        admin_id = "admin@antaksi.com"
        admin_hash = hash_password("Admin@123")
        c.execute(
            """
            INSERT INTO users (id, email, name, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                admin_id,
                admin_id,
                "Sistem Yöneticisi",
                admin_hash,
                UserRole.ADMIN.value,
                1,
                datetime.datetime.utcnow().isoformat()
            )
        )
    
    # Varsayılan ayarlar
    default_settings = [
        ("commission", "0.1", "Platform komisyon oranı"),
        ("min_fare", "20.0", "Minimum yolculuk ücreti"),
        ("base_fare", "10.0", "Temel açılış ücreti"),
        ("price_per_km_standard", "30.0", "Standart araç km başı ücret"),
        ("price_per_km_comfort", "40.0", "Confort araç km başı ücret"),
        ("price_per_km_premium", "50.0", "Premium araç km başı ücret"),
        ("surge_enabled", "1", "Dinamik fiyatlandırma aktif"),
        ("max_surge_multiplier", "2.5", "Maksimum fiyat çarpanı"),
        ("driver_search_radius_km", "10.0", "Sürücü arama yarıçapı"),
        ("ride_timeout_minutes", "5", "Sürücü kabul zaman aşımı"),
        ("cancel_penalty_user", "5.0", "Kullanıcı iptal cezası"),
        ("cancel_penalty_driver", "10.0", "Sürücü iptal cezası"),
    ]
    
    now = datetime.datetime.utcnow().isoformat()
    for key, value, description in default_settings:
        c.execute(
            """
            INSERT OR REPLACE INTO settings (key, value, description, updated_at, updated_by)
            VALUES (?, ?, ?, ?, ?)
            """,
            (key, value, description, now, "system")
        )
    
    conn.commit()
    conn.close()

# =============================================
# AUTH ENDPOINTS
# =============================================

@app.post("/auth/register", status_code=status.HTTP_201_CREATED)
async def register_user(request: RegisterRequest):
    """Yeni kullanıcı kaydı."""
    # Email veya telefon kontrolü
    if not request.email and not request.phone:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email veya telefon numarası gerekli"
        )
    
    # Parola validasyonu
    is_valid, message = validate_password(request.password)
    if not is_valid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Parola güvenli değil: {message}"
        )
    
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Kullanıcı ID'si oluştur
        user_id = request.email or request.phone
        
        # Var olan kullanıcı kontrolü
        existing = c.execute(
            "SELECT id FROM users WHERE id = ? OR email = ? OR phone = ?",
            (user_id, request.email, request.phone)
        ).fetchone()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bu email/telefon zaten kayıtlı"
            )
        
        # Parola hash'le
        password_hash = hash_password(request.password)
        now = datetime.datetime.utcnow().isoformat()
        
        # Kullanıcıyı oluştur
        c.execute(
            """
            INSERT INTO users (id, email, phone, name, password_hash, role, is_active, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                request.email,
                request.phone,
                request.name,
                password_hash,
                request.role.value,
                1 if request.role == UserRole.USER else 0,
                now
            )
        )
        
        # Rol'e göre ek tablolar
        if request.role == UserRole.USER:
            c.execute(
                "INSERT INTO customers (user_id) VALUES (?)",
                (user_id,)
            )
        elif request.role == UserRole.DRIVER:
            # Sürücü başvurusu oluşturulacak
            # Kullanıcı driver uygulaması yapmalı
            pass
        
        conn.commit()
        
        return {
            "message": "Kayıt başarılı",
            "user_id": user_id,
            "requires_driver_application": request.role == UserRole.DRIVER
        }
        
    finally:
        conn.close()

@app.post("/auth/login")
async def login_user(request: LoginRequest):
    """Kullanıcı girişi."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Kullanıcıyı bul (email, phone veya id ile)
        user = c.execute(
            """
            SELECT id, name, password_hash, role, is_active, is_banned 
            FROM users 
            WHERE id = ? OR email = ? OR phone = ?
            """,
            (request.identifier, request.identifier, request.identifier)
        ).fetchone()
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Kullanıcı bulunamadı"
            )
        
        # Parola kontrolü
        if not verify_password(user['password_hash'], request.password):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Hatalı parola"
            )
        
        # Rol kontrolü
        if user['role'] != request.role.value:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Rol uyumsuzluğu"
            )
        
        # Ban kontrolü
        if user['is_banned']:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Hesabınız askıya alınmış"
            )
        
        # Sürücü aktiflik kontrolü
        if user['role'] == 'driver':
            driver = c.execute(
                "SELECT documents_verified FROM drivers WHERE user_id = ?",
                (user['id'],)
            ).fetchone()
            
            if not driver or not driver['documents_verified']:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Sürücü belgeleriniz doğrulanmamış"
                )
        
        # Token oluştur
        payload = {
            "sub": user['id'],
            "name": user['name'],
            "role": user['role'],
            "is_active": bool(user['is_active'])
        }
        
        token = create_token(payload, expires_in=86400)  # 24 saat
        
        # Son giriş tarihini güncelle
        c.execute(
            "UPDATE users SET last_login = ? WHERE id = ?",
            (datetime.datetime.utcnow().isoformat(), user['id'])
        )
        conn.commit()
        
        return {
            "access_token": token,
            "token_type": "bearer",
            "expires_in": 86400,
            "user": {
                "id": user['id'],
                "name": user['name'],
                "role": user['role'],
                "is_active": bool(user['is_active'])
            }
        }
        
    finally:
        conn.close()

# =============================================
# DRIVER ENDPOINTS
# =============================================

@app.post("/drivers/apply")
async def apply_as_driver(
    request: DriverApplicationRequest,
    user: Dict = Depends(get_current_user)
):
    """Sürücü başvurusu."""
    if user['role'] != UserRole.USER.value:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Sadece yolcular sürücü başvurusu yapabilir"
        )
    
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Mevcut başvuru kontrolü
        existing = c.execute(
            "SELECT id FROM driver_applications WHERE user_id = ? AND status = 'pending'",
            (user['id'],)
        ).fetchone()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Zaten bekleyen bir başvurunuz var"
            )
        
        # Başvuru oluştur
        app_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO driver_applications 
            (id, user_id, name, email, phone, vehicle_type, vehicle_model, vehicle_year, 
             license_number, experience_years, price_per_km, lat, lon, status, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                app_id,
                user['id'],
                request.name,
                request.email,
                request.phone,
                request.vehicle_type.value,
                request.vehicle_model,
                request.vehicle_year,
                request.license_number,
                request.experience_years,
                request.price_per_km,
                request.lat,
                request.lon,
                'pending',
                now
            )
        )
        
        # Kullanıcı rolünü driver olarak güncelle (ama aktif değil)
        c.execute(
            "UPDATE users SET role = ? WHERE id = ?",
            (UserRole.DRIVER.value, user['id'])
        )
        
        conn.commit()
        
        return {
            "message": "Başvurunuz alındı",
            "application_id": app_id,
            "status": "pending"
        }
        
    finally:
        conn.close()

@app.get("/drivers/available")
async def get_available_drivers(
    lat: float = Query(..., ge=-90, le=90),
    lon: float = Query(..., ge=-180, le=180),
    vehicle_type: Optional[VehicleType] = None,
    user: Dict = Depends(require_role(UserRole.USER, UserRole.ADMIN))
):
    """Yakındaki müsait sürücüleri listele."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        query = """
            SELECT 
                d.user_id, d.vehicle_type, d.vehicle_model, d.vehicle_color,
                d.lat, d.lon, d.price_per_km, d.base_fare, d.min_fare,
                d.rating, d.total_rides,
                u.name,
                (6371 * acos(
                    cos(radians(?)) * cos(radians(d.lat)) * 
                    cos(radians(d.lon) - radians(?)) + 
                    sin(radians(?)) * sin(radians(d.lat))
                )) as distance_km
            FROM drivers d
            JOIN users u ON d.user_id = u.id
            WHERE d.available = 1 
            AND d.online = 1
            AND d.documents_verified = 1
            AND u.is_active = 1
            AND u.is_banned = 0
        """
        
        params = [lat, lon, lat]
        
        if vehicle_type:
            query += " AND d.vehicle_type = ?"
            params.append(vehicle_type.value)
        
        query += " ORDER BY distance_km LIMIT 20"
        
        rows = c.execute(query, params).fetchall()
        
        drivers = []
        for row in rows:
            drivers.append({
                "id": row['user_id'],
                "name": row['name'],
                "vehicle_type": row['vehicle_type'],
                "vehicle_model": row['vehicle_model'],
                "vehicle_color": row['vehicle_color'],
                "location": {
                    "lat": row['lat'],
                    "lon": row['lon']
                },
                "price_per_km": row['price_per_km'],
                "base_fare": row['base_fare'],
                "min_fare": row['min_fare'],
                "rating": row['rating'],
                "total_rides": row['total_rides'],
                "distance_km": row['distance_km'],
                "estimated_arrival": calculate_estimated_arrival(row['distance_km'])
            })
        
        return drivers
        
    finally:
        conn.close()

def calculate_estimated_arrival(distance_km: float) -> int:
    """Tahmini varış süresi (dakika)."""
    # Ortalama hız: 30 km/saat şehir içi
    if distance_km <= 1:
        return 3  # 3 dakika
    elif distance_km <= 5:
        return int(distance_km * 3)  # ~3 dakika/km
    else:
        return int(distance_km * 2.5)  # ~2.5 dakika/km (daha hızlı)

# =============================================
# RIDE ENDPOINTS
# =============================================

@app.post("/rides/request")
async def request_ride(
    request: RideRequest,
    user: Dict = Depends(require_role(UserRole.USER))
):
    """Yeni yolculuk talebi oluştur."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Mesafe hesapla
        distance_km = haversine_distance(
            request.start_location.lat,
            request.start_location.lon,
            request.end_location.lat,
            request.end_location.lon
        )
        
        # Süre tahmini
        duration_minutes = calculate_estimated_duration(distance_km)
        
        # Yakındaki sürücüleri bul
        drivers = c.execute(
            """
            SELECT d.*, u.name,
            (6371 * acos(
                cos(radians(?)) * cos(radians(d.lat)) * 
                cos(radians(d.lon) - radians(?)) + 
                sin(radians(?)) * sin(radians(d.lat))
            )) as distance_km
            FROM drivers d
            JOIN users u ON d.user_id = u.id
            WHERE d.available = 1 
            AND d.online = 1
            AND d.vehicle_type = ?
            AND d.documents_verified = 1
            AND u.is_active = 1
            AND u.is_banned = 0
            ORDER BY distance_km
            LIMIT 1
            """,
            (
                request.start_location.lat,
                request.start_location.lon,
                request.start_location.lat,
                request.vehicle_type.value
            )
        ).fetchone()
        
        if not drivers:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Uygun sürücü bulunamadı"
            )
        
        # Ücret hesapla
        price_calc = calculate_ride_price(
            distance_km=distance_km,
            duration_minutes=duration_minutes,
            price_per_km=drivers['price_per_km'],
            base_fare=drivers['base_fare'],
            min_fare=drivers['min_fare']
        )
        
        # Komisyon oranını al
        commission_row = c.execute(
            "SELECT value FROM settings WHERE key = 'commission'"
        ).fetchone()
        commission_rate = float(commission_row['value']) if commission_row else DEFAULT_COMMISSION
        
        # Final fiyat
        commission_amount = price_calc['total'] * commission_rate
        final_price = price_calc['total'] + commission_amount
        
        # Yolculuk oluştur
        ride_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO rides (
                id, customer_id, driver_id, vehicle_type,
                start_address, end_address,
                start_lat, start_lon, end_lat, end_lon,
                distance_km, duration_minutes,
                price_per_km, base_fare, total_price,
                commission_rate, commission_amount, final_price,
                status, payment_method,
                scheduled_time, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                ride_id,
                user['id'],
                drivers['user_id'],
                request.vehicle_type.value,
                "Başlangıç adresi",  # Geocode ile doldurulacak
                "Varış adresi",      # Geocode ile doldurulacak
                request.start_location.lat,
                request.start_location.lon,
                request.end_location.lat,
                request.end_location.lon,
                distance_km,
                duration_minutes,
                drivers['price_per_km'],
                drivers['base_fare'],
                price_calc['total'],
                commission_rate,
                commission_amount,
                final_price,
                RideStatus.PENDING.value,
                request.payment_method.value,
                request.scheduled_time.isoformat() if request.scheduled_time else None,
                now
            )
        )
        
        # Sürücüyü meşgul olarak işaretle
        c.execute(
            "UPDATE drivers SET available = 0 WHERE user_id = ?",
            (drivers['user_id'],)
        )
        
        # Bildirim oluştur
        notification_id = str(uuid.uuid4())
        c.execute(
            """
            INSERT INTO notifications (id, user_id, title, message, notification_type, related_id, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                notification_id,
                drivers['user_id'],
                "Yeni Yolculuk Talebi",
                f"{user['name']} size yolculuk talebi gönderdi",
                "ride",
                ride_id,
                now
            )
        )
        
        conn.commit()
        
        # WebSocket bildirimi gönder
        await manager.send_personal_message(
            json.dumps({
                "type": "new_ride",
                "ride_id": ride_id,
                "customer_name": user['name'],
                "pickup_location": {
                    "lat": request.start_location.lat,
                    "lon": request.start_location.lon
                },
                "price": final_price
            }),
            drivers['user_id']
        )
        
        return {
            "message": "Yolculuk talebi oluşturuldu",
            "ride_id": ride_id,
            "driver_id": drivers['user_id'],
            "driver_name": drivers['name'],
            "estimated_arrival": calculate_estimated_arrival(drivers['distance_km']),
            "price_breakdown": {
                "base_fare": price_calc['base_fare'],
                "distance_fare": price_calc['distance_fare'],
                "time_fare": price_calc['time_fare'],
                "subtotal": price_calc['subtotal'],
                "commission": commission_amount,
                "total": final_price
            }
        }
        
    finally:
        conn.close()

def calculate_estimated_duration(distance_km: float) -> float:
    """Tahmini yolculuk süresi (dakika)."""
    # Ortalama hız: 25 km/saat şehir içi
    hours = distance_km / 25
    return hours * 60

# =============================================
# WEBSOCKET ENDPOINTS
# =============================================

@app.websocket("/ws/{user_id}")
async def websocket_endpoint(websocket: WebSocket, user_id: str):
    """WebSocket bağlantısı."""
    await manager.connect(websocket, user_id)
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            # Konum güncelleme
            if message.get("type") == "location_update":
                if message.get("role") == "driver":
                    lat = message.get("lat")
                    lon = message.get("lon")
                    if lat and lon:
                        manager.update_driver_location(user_id, lat, lon)
            
            # Canlı yolculuk takibi
            elif message.get("type") == "ride_tracking":
                ride_id = message.get("ride_id")
                # Yolculuk durumunu güncelle
            
            # Mesajlaşma
            elif message.get("type") == "message":
                to_user = message.get("to_user")
                content = message.get("content")
                if to_user:
                    await manager.send_personal_message(
                        json.dumps({
                            "type": "message",
                            "from": user_id,
                            "content": content,
                            "timestamp": datetime.datetime.utcnow().isoformat()
                        }),
                        to_user
                    )
                    
    except WebSocketDisconnect:
        manager.disconnect(user_id)

# =============================================
# PAYMENT ENDPOINTS
# =============================================

@app.post("/payments/create")
async def create_payment(
    request: PaymentRequest,
    user: Dict = Depends(require_role(UserRole.USER))
):
    """Ödeme oluştur."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Yolculuğu kontrol et
        ride = c.execute(
            """
            SELECT r.*, d.user_id as driver_id
            FROM rides r
            JOIN drivers d ON r.driver_id = d.user_id
            WHERE r.id = ? AND r.customer_id = ?
            """,
            (request.ride_id, user['id'])
        ).fetchone()
        
        if not ride:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Yolculuk bulunamadı"
            )
        
        if ride['payment_status'] == PaymentStatus.PAID.value:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bu yolculuk zaten ödenmiş"
            )
        
        # Ödeme oluştur
        payment_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO payments (
                id, ride_id, customer_id, driver_id, amount,
                commission_amount, payment_method, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                payment_id,
                request.ride_id,
                user['id'],
                ride['driver_id'],
                ride['final_price'],
                ride['commission_amount'],
                request.payment_method.value,
                PaymentStatus.PENDING.value,
                now
            )
        )
        
        # Cüzdan ödemesi
        if request.payment_method == PaymentMethod.WALLET:
            # Cüzdan bakiyesini kontrol et
            user_balance = c.execute(
                "SELECT wallet_balance FROM users WHERE id = ?",
                (user['id'],)
            ).fetchone()['wallet_balance']
            
            if user_balance < ride['final_price']:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail="Cüzdan bakiyeniz yetersiz"
                )
            
            # Bakiyeden düş
            c.execute(
                "UPDATE users SET wallet_balance = wallet_balance - ? WHERE id = ?",
                (ride['final_price'], user['id'])
            )
            
            # Sürücüye ekle
            driver_earnings = ride['final_price'] - ride['commission_amount']
            c.execute(
                "UPDATE drivers SET earnings_total = earnings_total + ? WHERE user_id = ?",
                (driver_earnings, ride['driver_id'])
            )
            
            # Ödemeyi tamamla
            c.execute(
                "UPDATE payments SET status = ?, completed_at = ? WHERE id = ?",
                (PaymentStatus.PAID.value, now, payment_id)
            )
            
            # Yolculuk ödeme durumunu güncelle
            c.execute(
                "UPDATE rides SET payment_status = ? WHERE id = ?",
                (PaymentStatus.PAID.value, request.ride_id)
            )
        
        conn.commit()
        
        return {
            "message": "Ödeme oluşturuldu",
            "payment_id": payment_id,
            "amount": ride['final_price'],
            "status": PaymentStatus.PAID.value if request.payment_method == PaymentMethod.WALLET else PaymentStatus.PENDING.value
        }
        
    finally:
        conn.close()

# =============================================
# RATING ENDPOINTS
# =============================================

@app.post("/ratings/create")
async def create_rating(
    request: RatingRequest,
    user: Dict = Depends(get_current_user)
):
    """Değerlendirme oluştur."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Yolculuğu kontrol et
        ride = c.execute(
            "SELECT * FROM rides WHERE id = ? AND status = 'completed'",
            (request.ride_id,)
        ).fetchone()
        
        if not ride:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Yolculuk bulunamadı veya tamamlanmamış"
            )
        
        # Kim kime değerlendirme yapıyor?
        if user['id'] == ride['customer_id']:
            # Yolcu sürücüyü değerlendiriyor
            to_user_id = ride['driver_id']
        elif user['id'] == ride['driver_id']:
            # Sürücü yolcuyu değerlendiriyor
            to_user_id = ride['customer_id']
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Bu yolculuğa değerlendirme yapma yetkiniz yok"
            )
        
        # Daha önce değerlendirme yapılmış mı?
        existing = c.execute(
            "SELECT id FROM ratings WHERE ride_id = ? AND from_user_id = ?",
            (request.ride_id, user['id'])
        ).fetchone()
        
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Bu yolculuk için zaten değerlendirme yaptınız"
            )
        
        # Değerlendirmeyi kaydet
        rating_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO ratings (id, ride_id, from_user_id, to_user_id, rating, comment, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                rating_id,
                request.ride_id,
                user['id'],
                to_user_id,
                request.rating,
                request.comment,
                now
            )
        )
        
        # Kullanıcının ortalama rating'ini güncelle
        avg_rating = c.execute(
            """
            SELECT AVG(rating) as avg_rating 
            FROM ratings 
            WHERE to_user_id = ?
            """,
            (to_user_id,)
        ).fetchone()['avg_rating']
        
        c.execute(
            "UPDATE users SET rating = ? WHERE id = ?",
            (avg_rating, to_user_id)
        )
        
        # Sürücü ise drivers tablosunu da güncelle
        if user['role'] == 'driver':
            c.execute(
                "UPDATE drivers SET rating = ? WHERE user_id = ?",
                (avg_rating, to_user_id)
            )
        
        conn.commit()
        
        return {
            "message": "Değerlendirme kaydedildi",
            "rating_id": rating_id,
            "average_rating": avg_rating
        }
        
    finally:
        conn.close()

# =============================================
# ADDRESS ENDPOINTS
# =============================================

@app.post("/addresses")
async def create_address(
    request: AddressRequest,
    user: Dict = Depends(require_role(UserRole.USER))
):
    """Yeni adres kaydet."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Varsayılan adres varsa güncelle
        if request.is_default:
            c.execute(
                "UPDATE user_addresses SET is_default = 0 WHERE user_id = ?",
                (user['id'],)
            )
        
        # Adresi kaydet
        address_id = str(uuid.uuid4())
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO user_addresses (id, user_id, title, address, lat, lon, is_default, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                address_id,
                user['id'],
                request.title,
                request.address,
                request.lat,
                request.lon,
                1 if request.is_default else 0,
                now
            )
        )
        
        conn.commit()
        
        return {
            "message": "Adres kaydedildi",
            "address_id": address_id
        }
        
    finally:
        conn.close()

@app.get("/addresses")
async def get_addresses(
    user: Dict = Depends(require_role(UserRole.USER))
):
    """Kayıtlı adresleri listele."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        rows = c.execute(
            """
            SELECT id, title, address, lat, lon, is_default, created_at
            FROM user_addresses
            WHERE user_id = ?
            ORDER BY is_default DESC, created_at DESC
            """,
            (user['id'],)
        ).fetchall()
        
        addresses = []
        for row in rows:
            addresses.append({
                "id": row['id'],
                "title": row['title'],
                "address": row['address'],
                "location": {
                    "lat": row['lat'],
                    "lon": row['lon']
                },
                "is_default": bool(row['is_default']),
                "created_at": row['created_at']
            })
        
        return addresses
        
    finally:
        conn.close()

# =============================================
# ADMIN ENDPOINTS
# =============================================

@app.get("/admin/driver-applications")
async def get_driver_applications(
    user: Dict = Depends(require_role(UserRole.ADMIN))
):
    """Sürücü başvurularını listele."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        rows = c.execute(
            """
            SELECT da.*, u.created_at as user_created
            FROM driver_applications da
            JOIN users u ON da.user_id = u.id
            WHERE da.status = 'pending'
            ORDER BY da.created_at DESC
            """
        ).fetchall()
        
        applications = []
        for row in rows:
            applications.append({
                "id": row['id'],
                "user_id": row['user_id'],
                "name": row['name'],
                "email": row['email'],
                "phone": row['phone'],
                "vehicle_type": row['vehicle_type'],
                "vehicle_model": row['vehicle_model'],
                "vehicle_year": row['vehicle_year'],
                "license_number": row['license_number'],
                "experience_years": row['experience_years'],
                "price_per_km": row['price_per_km'],
                "location": {
                    "lat": row['lat'],
                    "lon": row['lon']
                },
                "status": row['status'],
                "notes": row['notes'],
                "created_at": row['created_at'],
                "user_since": row['user_created']
            })
        
        return applications
        
    finally:
        conn.close()

@app.post("/admin/driver-applications/{app_id}/approve")
async def approve_driver_application(
    app_id: str,
    user: Dict = Depends(require_role(UserRole.ADMIN))
):
    """Sürücü başvurusunu onayla."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Başvuruyu bul
        application = c.execute(
            "SELECT * FROM driver_applications WHERE id = ? AND status = 'pending'",
            (app_id,)
        ).fetchone()
        
        if not application:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Başvuru bulunamadı veya zaten işlenmiş"
            )
        
        # Sürücüyü oluştur
        now = datetime.datetime.utcnow().isoformat()
        
        c.execute(
            """
            INSERT INTO drivers (
                user_id, license_number, vehicle_type, vehicle_model,
                lat, lon, available, price_per_km, base_fare, min_fare,
                documents_verified, online, last_ride_end
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                application['user_id'],
                application['license_number'],
                application['vehicle_type'],
                application['vehicle_model'],
                application['lat'],
                application['lon'],
                1,  # available
                application['price_per_km'],
                10.0,  # base_fare
                20.0,  # min_fare
                1,  # documents_verified (admin onayladı)
                1,  # online
                now
            )
        )
        
        # Kullanıcıyı aktif yap
        c.execute(
            "UPDATE users SET is_active = 1, role = ? WHERE id = ?",
            (UserRole.DRIVER.value, application['user_id'])
        )
        
        # Başvuru durumunu güncelle
        c.execute(
            """
            UPDATE driver_applications 
            SET status = 'approved', reviewed_by = ?, reviewed_at = ?
            WHERE id = ?
            """,
            (user['id'], now, app_id)
        )
        
        # Bildirim gönder
        notification_id = str(uuid.uuid4())
        c.execute(
            """
            INSERT INTO notifications (id, user_id, title, message, notification_type, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                notification_id,
                application['user_id'],
                "Başvurunuz Onaylandı!",
                "Tebrikler! Sürücü başvurunuz onaylandı. Artık yolcu alabilirsiniz.",
                "system",
                now
            )
        )
        
        conn.commit()
        
        return {
            "message": "Sürücü başvurusu onaylandı",
            "driver_id": application['user_id']
        }
        
    finally:
        conn.close()

# =============================================
# STATISTICS ENDPOINTS
# =============================================

@app.get("/stats/overview")
async def get_overview_stats(
    user: Dict = Depends(require_role(UserRole.ADMIN))
):
    """Genel istatistikler."""
    conn = get_db_connection()
    c = conn.cursor()
    
    try:
        # Toplam kullanıcılar
        total_users = c.execute(
            "SELECT COUNT(*) as count FROM users"
        ).fetchone()['count']
        
        # Aktif sürücüler
        active_drivers = c.execute(
            "SELECT COUNT(*) as count FROM drivers WHERE online = 1 AND available = 1"
        ).fetchone()['count']
        
        # Bugünkü yolculuklar
        today = datetime.datetime.utcnow().date().isoformat()
        today_rides = c.execute(
            "SELECT COUNT(*) as count FROM rides WHERE DATE(created_at) = ?",
            (today,)
        ).fetchone()['count']
        
        # Toplam ciro
        total_revenue = c.execute(
            "SELECT SUM(final_price) as total FROM rides WHERE payment_status = 'paid'"
        ).fetchone()['total'] or 0
        
        # Bugünkü ciro
        today_revenue = c.execute(
            "SELECT SUM(final_price) as total FROM rides WHERE DATE(created_at) = ? AND payment_status = 'paid'",
            (today,)
        ).fetchone()['total'] or 0
        
        # Son 7 günün yolculukları
        last_7_days = []
        for i in range(6, -1, -1):
            day = (datetime.datetime.utcnow() - timedelta(days=i)).date().isoformat()
            day_rides = c.execute(
                "SELECT COUNT(*) as count FROM rides WHERE DATE(created_at) = ?",
                (day,)
            ).fetchone()['count']
            
            last_7_days.append({
                "date": day,
                "rides": day_rides
            })
        
        return {
            "total_users": total_users,
            "active_drivers": active_drivers,
            "today_rides": today_rides,
            "total_revenue": float(total_revenue),
            "today_revenue": float(today_revenue),
            "last_7_days": last_7_days
        }
        
    finally:
        conn.close()

# =============================================
# HEALTH CHECK
# =============================================

@app.get("/health")
async def health_check():
    """Sistem sağlık kontrolü."""
    try:
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("SELECT 1")
        conn.close()
        
        return {
            "status": "healthy",
            "timestamp": datetime.datetime.utcnow().isoformat(),
            "version": "2.0.0",
            "database": "connected"
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Service unhealthy: {str(e)}"
        )

# =============================================
# ERROR HANDLERS
# =============================================

@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": exc.detail,
            "code": exc.status_code,
            "timestamp": datetime.datetime.utcnow().isoformat()
        }
    )

@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal server error",
            "code": 500,
            "timestamp": datetime.datetime.utcnow().isoformat()
        }
    )

# =============================================
# MAIN EXECUTION
# =============================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "antaksi_secure_api:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )