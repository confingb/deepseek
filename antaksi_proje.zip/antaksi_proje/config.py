import os

basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = 'antaksi-pro-super-secret-2025!'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///' + os.path.join(basedir, 'instance', 'antaksi.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    BASE_FARE = 15.0
    PER_KM_DAY = 8.5
    PER_KM_NIGHT = 10.0
    PER_MINUTE = 1.2
    MINIMUM_FARE = 30.0
    
    DISTRICTS = ['Şişli', 'Beşiktaş', 'Kadıköy', 'Üsküdar', 'Fatih', 'Beyoğlu', 'Bakırköy']
    
    VEHICLE_TYPES = {
        'standard': {'name': 'Standart', 'multiplier': 1.0, 'icon': '🚗'},
        'comfort': {'name': 'Konfor', 'multiplier': 1.3, 'icon': '🚙'},
        'premium': {'name': 'Premium', 'multiplier': 1.7, 'icon': '🚘'}
    }